#include "opensdl.h"
#include <glad/gl.h>
#include <SDL3/SDL.h>

int main() {
    if (!opensdl_init(800, 600, "OpenSDL Starter")) return 1;

    OS_Event ev;
    while (true) {
        while (opensdl_poll(&ev)) {
            if (ev.type == 1) return 0;
        }

        opensdl_clear(0.1f, 0.2f, 0.3f, 1.0f);
        // Możesz użyć glDrawArrays, glUseProgram itd.
        opensdl_swap();
    }

    opensdl_quit();
    return 0;
}
