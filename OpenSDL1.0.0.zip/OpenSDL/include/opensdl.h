#ifndef OPENSDL_H
#define OPENSDL_H

#ifdef _WIN32
#  ifdef OPENSDL_EXPORTS
#    define OPENSDL_API __declspec(dllexport)
#  else
#    define OPENSDL_API __declspec(dllimport)
#  endif
#else
#  define OPENSDL_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
    int type;
} OS_Event;

OPENSDL_API bool opensdl_init(int width, int height, const char* title);
OPENSDL_API void opensdl_clear(float r, float g, float b, float a);
OPENSDL_API bool opensdl_poll(OS_Event* out);
OPENSDL_API void opensdl_swap();
OPENSDL_API void opensdl_quit();

#ifdef __cplusplus
}
#endif

#endif
