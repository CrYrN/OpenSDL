#include "opensdl.h"
#include <SDL3/SDL.h>
#include <glad/glad.h>

static SDL_Window* window = nullptr;
static SDL_GLContext context = nullptr;

bool opensdl_init(int width, int height, const char* title) {
    if (SDL_Init(SDL_INIT_VIDEO) != 0) return false;

    window = SDL_CreateWindow(title, width, height, SDL_WINDOW_OPENGL);
    if (!window) return false;

    context = SDL_GL_CreateContext(window);
    if (!context) return false;

    if (!gladLoadGLLoader((GLADloadproc)SDL_GL_GetProcAddress)) return false;

    return true;
}

void opensdl_clear(float r, float g, float b, float a) {
    glClearColor(r, g, b, a);
    glClear(GL_COLOR_BUFFER_BIT);
}

bool opensdl_poll(OS_Event* out) {
    SDL_Event e;
    if (SDL_PollEvent(&e)) {
        if (e.type == SDL_EVENT_QUIT) {
            out->type = 1;
            return true;
        }
    }
    out->type = 0;
    return false;
}

void opensdl_swap() {
    SDL_GL_SwapWindow(window);
}

void opensdl_quit() {
    SDL_GL_DestroyContext(context);
    SDL_DestroyWindow(window);
    SDL_Quit();
}
